Setup.txt - How to setup the application for first use
License.txt - Licence of the NTPAD.exe
